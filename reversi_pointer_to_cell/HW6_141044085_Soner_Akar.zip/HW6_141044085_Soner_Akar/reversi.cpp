//
//  reversi.cpp
//  withheader
//
//  Created by Soner on 11.12.2015.
//  Copyright © 2015 Soner. All rights reserved.
//

#include "reversi.h"
#include <iostream>
#include <cstdlib>
using namespace std;

namespace REVERSI {
    
    int Reversi::countAlive = 0;
    
    /*---- Call by reference ----*/
    
    void testRef(Reversi& obj)
    {
        cout << "test call - by - reference function" << endl;
        obj++;
        obj.show();
    }
    
    /*---- Call by value ----*/
    
    void testCal(Reversi obj)
    {
        cout << "test call by value" << endl;
        cout << "---" << obj.countFunc() << " games alive---" << endl;
    }
    
    bool Reversi::check_boundry_for_rival(const int i,const int j,
                                          const int around_r,const int around_c,const int row,const int col) const
    {
        return
        (i == 0 && around_r == -1) || i + around_r >= row || // outta up range
        (j == 0 && around_c == -1) || j + around_c >= col || // outta down range
        (around_r == 0 && around_c == 0);// if the coordinate itself
        
    }
    
    bool Reversi::check_boundry_for_player(const int i,const int j, const int row,const int col) const
    {
        return row - 1 < i || i < 0 || col - 1 < j || j < 0;
    }
    
    char Reversi::specify_rival(const char player) const
    {
        if ( p_symbol == player )
            return c_symbol;
        return p_symbol;
    }
    Reversi::~Reversi()
    {
        delete [] gameCells;
        //--countAlive;
    }
    
    Reversi Reversi::operator= (const Reversi& other)
    {
        char ch;
        int coors;
        if (this == &other)
        {
            return *this;
        }
        
        row = other.row;
        col = other.col;
        
        moves = other.moves;
        
        
        for(int i = 0 ; i < row ; ++i)
            for(int j = 0 ; j < col ; ++j)
            {
                ch = other.gameCells[i * col + j].getChar();
                gameCells[i * col + j].setChar(ch);
                coors = other.gameCells[i * col + j].getX();
                gameCells[i * col + j].setX(coors);
                coors = other.gameCells[i * col + j].getY();
                gameCells[i * col + j].setY(coors);
            }
        
        return *this;
    }
    
    Reversi::Reversi(const Reversi& other)
    {
        row = other.row;
        col = other.col;
        
        moves = other.moves;
        
        gameCells = new Cell[row * col];
        char ch;
        int coors;
        
        for(int i = 0 ; i < row ; ++i)
            for(int j = 0 ; j < col ; ++j)
            {
                ch = other.gameCells[i * col + j].getChar();
                gameCells[i * col + j].setChar(ch);
                coors = other.gameCells[i * col + j].getX();
                gameCells[i * col + j].setX(coors);
                coors = other.gameCells[i * col + j].getY();
                gameCells[i * col + j].setY(coors);
            }
        
    }
    
    /* ---- REVERSI OPERATOR OVERLOADINGS ----*/
    
    ostream& operator<<(ostream& out, const Reversi& other)
    {
        other.show();
        return out;
    }
    
    void Reversi::operator++(int dummy)
    {
        ++(*this);
    }
    
    Reversi& Reversi::operator++()
    {
        play();
        return *this;
    }
    /* ---- BELONG TO THE Reversi CLASS ---- */
    
    // takes a step back
    
    
    // Taking a Reversi object to compare which better
    
    bool Reversi::comparator(const Reversi& obj) const
    {
        int firstObj = 0;
        int secondObj = 0;
        
        for (unsigned int i = 0; i < row; ++i)
        {
            for (unsigned int j = 0; j < col; ++j)
            {
                if (gameCells[i * col + j].getChar() == p_symbol)
                {
                    ++firstObj;
                }
            }
        }
        
        for (unsigned int i = 0; i < obj.row; ++i)
        {
            for (unsigned int j = 0; j < obj.col; ++j)
            {
                if (obj.gameCells[i * col + j].getChar() == p_symbol)
                {
                    ++secondObj;
                }
            }
        }
        
        return firstObj > secondObj;
        
    }
    
    
    // check whether the game end or not
    
    bool Reversi::checker() const
    {
        return moveCount < row * col && playable;
    }
    
    int Reversi::countFunc()
    {
        return countAlive;
    }
    
    // plays game normally
    
    void Reversi::playGame()
    {
        Cell temp;
        int x;
        int y;
        
        
        cout << "Enter board sizes => ";
        cin >> x >> y;
        setRowCol(x, y);
        
        
        do
        {
            show();    // print the board on terminal
            
            if((p_turn = !p_turn))  // specify whose turn true for human
            {
                play(temp);
            }
            else
            {
                play();
            }
            
        }while (checker());
        
        show();
        
        char *symbolHold = new char[row * col];
        for(int i = 0 ; i < row ; ++i)
            for(int j = 0 ; j < col ; ++j)
            {
                symbolHold[i * col + j] = gameCells[i * col + j].getChar();
            }
        
        
        cout << "----------The Score Table----------" << endl;
        cout << "Computer => " << symbol_counter(symbolHold, c_symbol) << endl;
        cout << "Player => " << std::setw(colAlignment) << symbol_counter(symbolHold, p_symbol) << endl;
        
        delete [] symbolHold;
        
    }
    
    // play single step for computer
    
    void Reversi::play()
    {
        char *holdChars = new char[row * col];
        
        for(int i = 0 ; i < row ; ++i)
            for(int j = 0 ; j < col ; ++j)
            {
                holdChars[i * col + j] = gameCells[i * col + j].getChar();
            }
        
        if(playable_moves(holdChars, moves, c_symbol))
        {
            moveCount += 1;    // upgrade counter for alive cell
            illegalMove = 0;   // the machine is already played,
            //so get reset the illegal counter
            // convert symbols of the rival to symbols of the machine
            machine_moves(holdChars, c_symbol);
        }
        else
        {   // there is no legal wriggling for the machine
            illegalMove += 1;
            if(1 >= illegalMove)
                cout << "The computer doesn't have"
                << "any playable movement, your turn" << endl;
            else // there is no legal wriggling for the machine and the human
            {
                cout << "The machine and the human"
                << " don't have any movements" << endl;
                playable = false;
            }
        }
        
        for(int i = 0 ; i < row ; ++i)
            for(int j = 0 ; j < col ; ++j)
            {
                gameCells[i * col + j].setChar(holdChars[i * col + j]);
            }
        
        delete [] holdChars;
    }
    
    // plays computer single step
    
    void Reversi::play(Cell var)
    {
        int tempX;
        int tempY;
        char *holdChars = new char[row * col];
        
        
        
        for(int i = 0 ; i < row ; ++i)
            for(int j = 0 ; j < col ; ++j)
            {
                holdChars[i * col + j] = gameCells[i * col + j].getChar();
            }
        
        if(playable_moves(holdChars, moves, p_symbol)) // check playable dots by human
        {
            // boundry and mark checking
            cout << "To save press -1"
            << "\nEnter the coordinates to play => ";
            // get inputs
            cin >> tempX;
            
            if (tempX == -1)
            {
                cout << "You can continue to play enter coors => ";
                cin >> tempX;
            }
            tempX -= 1;  // fix the entered x coordinate
            
            cin >> tempY;
            // fix the entered y coordinate
            tempY -= 1;
            
            var.setX(tempX);
            var.setY(tempY);
            
            while(check_boundry_for_player(var.getX(), var.getY(), row, col)
                  || moves[var.getX()][var.getY()] == false)
            {
                cout << "Illegal wriggling. Try again" << endl;
                
                // Re-enter the coordinates until entered rightly
                
                cout << "Enter the coordinates to play => ";
                // get inputs
                cin >> tempX;
                tempX -= 1;  // fix the entered x coordinate
                cin >> tempY;
                // fix the entered y coordinate
                tempY -= 1;
                
                var.setX(tempX);
                var.setY(tempY);
            }
            // convert symbols of the rival to symbols of the human
            mover(holdChars, var.getX(), var.getY(), p_symbol);
            moveCount += 1;    // upgrade both counter for alive cell
        }
        else
        {
            // there is no legal wriggling
            illegalMove += 1;
            if(1 >= illegalMove)
                cout << "You don't have playable move,"
                << "so the machine is playing again" << endl;
            else
            {
                cout << "The machine and the human don't have any movements" << endl;
                playable = false;
            }
        }
        
        for(int i = 0 ; i < row ; ++i)
            for(int j = 0 ; j < col ; ++j)
            {
                gameCells[i * col + j].setChar(holdChars[i * col + j]);
            }
        
        delete [] holdChars;
    }
    
    // print the grid on the screen
    
    void Reversi::show() const
    {
        int tempCol;
        int countDigit = 0;
        
        
        cout << endl << setw(colAlignment);
        for(int i = 0 ; i < col ; ++i)
            cout << i + 1;
        cout << endl;
        
        for(int i = 0; i < row; ++i)
        {
            cout << setw(rowAlignment) << i + 1;
            
            
            for(int j = 0; j < col; ++j)
            {
                
                tempCol = j;
                while(tempCol > 0)
                {
                    countDigit++;
                    tempCol /= 10;
                }
                
                for (int k = 0; k < countDigit - 1; ++k)
                {
                    cout << " ";
                }
                
                cout << gameCells[i * col + j].getChar();
                
                countDigit = 0;
            }
            cout << endl;
        }
        cout << endl;
    }
    
    // ctor for no arguments
    
    Reversi::Reversi()
    : row(MIN_SIZE + MIN_SIZE), col(MIN_SIZE + MIN_SIZE)
    {
        ++countAlive;
        wrongInput.setX(-1000);
        wrongInput.setY(-1000);
        
        moves.resize(row);
        for (int i = 0; i < row; ++i)
            moves[i].resize(col);
        
        gameCells = new Cell[row * col];
        
        
        for(int i = 0; i < row; ++i)
            for(int j = 0; j < col; ++j)
            {
                moves[i][j] = false;
                gameCells[i * col + j].setChar(what_symbol);
            }
        
        int centerh = row / 2;
        int centerw = col / 2;
        
        gameCells[centerh * col + centerw].setChar(c_symbol);
        gameCells[(centerh - 1) * col + centerw - 1].setChar(c_symbol);
        
        gameCells[centerh * col + (centerw - 1)].setChar(p_symbol);
        gameCells[(centerh - 1) * col + centerw].setChar(p_symbol);
        
        moveCount = MIN_SIZE + MIN_SIZE;
        illegalMove = 0;
        p_turn = false;
        playable = true;
        
    }
    
    // ctor for single arguments
    
    Reversi::Reversi(int size)
    : row(size), col(size)
    {
        boardSizeCheck();
        ++countAlive;
        wrongInput.setX(-1000);
        wrongInput.setY(-1000);
        
        moves.resize(row);
        for (int i = 0; i < row; ++i)
            moves[i].resize(col);
        
        gameCells = new Cell[row * col];
        
        
        for(int i = 0; i < row; ++i)
            for(int j = 0; j < col; ++j)
            {
                moves[i][j] = false;
                gameCells[i * col + j].setChar(what_symbol);
            }
        
        int centerh = row / 2;
        int centerw = col / 2;
        
        gameCells[centerh * col + centerw].setChar(c_symbol);
        gameCells[(centerh - 1) * col + centerw - 1].setChar(c_symbol);
        
        gameCells[centerh * col + (centerw - 1)].setChar(p_symbol);
        gameCells[(centerh - 1) * col + centerw].setChar(p_symbol);
        
        moveCount = MIN_SIZE + MIN_SIZE;
        illegalMove = 0;
        p_turn = false;
        playable = true;
        
    }
    
    // ctor for two arguments
    
    Reversi::Reversi(const int x,const int y)
    : row(x), col(y)
    {
        ++countAlive;
        boardSizeCheck();
        
        wrongInput.setX(-1000);
        wrongInput.setY(-1000);
        
        moves.resize(row);
        for (int i = 0; i < row; ++i)
            moves[i].resize(col);
        
        gameCells = new Cell[row * col];
        
        
        for(int i = 0; i < row; ++i)
            for(int j = 0; j < col; ++j)
            {
                moves[i][j] = false;
                gameCells[i * col + j].setChar(what_symbol);
            }
        
        int centerh = row / 2;
        int centerw = col / 2;
        
        gameCells[centerh * col + centerw].setChar(c_symbol);
        gameCells[(centerh - 1) * col + centerw - 1].setChar(c_symbol);
        
        gameCells[centerh * col + (centerw - 1)].setChar(p_symbol);
        gameCells[(centerh - 1) * col + centerw].setChar(p_symbol);
        
        moveCount = MIN_SIZE + MIN_SIZE;
        illegalMove = 0;
        p_turn = false;
        playable = true;
        
    }
    // getter for row
    
    int Reversi::getRow() const
    {
        return row;
    }
    
    // getter for column
    
    int Reversi::getCol() const
    {
        return col;
    }
    
    // setter for row and column
    
    void Reversi::setRowCol(const int _row,const int _col)
    {
        
        
        moves.clear();
        
        setRow(_row);
        setCol(_col);
        
        boardSizeCheck();
        
        moves.resize(row);
        for (int i = 0; i < row; ++i)
            moves[i].resize(col);
        
        gameCells = new Cell[row * col];
        
        
        for(int i = 0; i < row; ++i)
            for(int j = 0; j < col; ++j)
            {
                moves[i][j] = false;
                gameCells[i * col + j].setChar(what_symbol);
            }
        
        int centerh = row / 2;
        int centerw = col / 2;
        
        gameCells[centerh * col + centerw].setChar(c_symbol);
        gameCells[(centerh - 1) * col + centerw - 1].setChar(c_symbol);
        
        gameCells[centerh * col + (centerw - 1)].setChar(p_symbol);
        gameCells[(centerh - 1) * col + centerw].setChar(p_symbol);
    }
    
    // check board size is ok
    
    void Reversi::boardSizeCheck() const
    {
        if (row < MIN_SIZE || col < MIN_SIZE)
        {
            cerr << "Minimum input sizes should be 2 x 2" << endl;
            exit(0);
        }
    }
    
    
    
    /*----------------------------------------*/
    
    void Reversi::machine_moves(char *tempBoard, const  char player) const    ////////////
    {
        char *holdChars = new char[row * col];
        int eff_i = 0;
        int eff_j = 0;
        int score = 0;
        int min_score_for_o = row * col + 1;
        char *copy_board = new char[row * col];
        vector< vector<bool> > copy_wriggles;
        
        
        
        copy_wriggles.resize(row);
        for (int i = 0; i < row; ++i)
            copy_wriggles[i].resize(col);
        
        for(int i = 0 ; i < row ; ++i)
            for(int j = 0 ; j < col ; ++j)
            {
                if(moves[i][j] == false)     // marked true go on otherwise
                    continue;                   // increment the loop
                
                for(int i = 0 ; i < row ; ++i)
                    for(int j = 0 ; j < col ; ++j)
                    {
                        copy_board[i * col + j] = tempBoard[i * col + j];
                    }
                
                // play on copy_board
                mover(copy_board, i, j, player);
                
                // search playable wriggles by the rival after this play of the player
                playable_moves(copy_board, copy_wriggles, specify_rival(player));
                
                
                // search the most efficient proper coordinates
                score = not_smart_not_bad(copy_board, copy_wriggles, specify_rival(player));
                if(score < min_score_for_o)
                {
                    eff_i = i;
                    eff_j = j;
                    min_score_for_o = score;
                }
            }
        mover(tempBoard, eff_i, eff_j, player);
        
        cout << "----" << eff_i + 1 << " " << eff_j + 1 << "----"
        << " was played by the machine" << endl;
        
        delete [] holdChars;
        delete [] copy_board;
        
        
    }
    
    
    void Reversi::mover(char *tempBoard, const int i,const int j,const  char player) const  /////////////
    {
        bool go_on;
        tempBoard[i * col + j] = player;
        
        for(int ii = 1 ; ii > -2 ; --ii)
            for(int jj = 1 ; jj > -2 ; --jj)
            {
                if(check_boundry_for_rival(i, j, ii, jj, row, col))
                    continue;
                
                if(specify_rival(player) == tempBoard[(i + ii) * col + (j + jj)])
                {
                    go_on = true;
                    int x_coor = i + ii;
                    int y_coor = j + jj;
                    
                    while(go_on)
                    {
                        x_coor += ii;
                        y_coor += jj;
                        
                        
                        if(check_boundry_for_player(x_coor, y_coor, row, col)
                           || tempBoard[x_coor * col + y_coor] == what_symbol)
                            go_on = false;
                        
                        else if(player == tempBoard[x_coor * col + y_coor])
                        {
                            x_coor -= ii;
                            y_coor -= jj;
                            
                            while(specify_rival(player) == tempBoard[x_coor * col + y_coor])
                            {
                                tempBoard[x_coor * col + y_coor] = player;
                                x_coor -= ii;
                                y_coor -= jj;
                                
                                
                            }
                            go_on = false;
                        }
                    }
                }
            }
    }
    
    int Reversi::symbol_counter(const char *tempBoard, const  char player) const    //////////////
    {
        int count = 0;
        for(int i = 0 ; i < row ; ++i)
            for(int j = 0 ; j < col ; ++j)
                if(tempBoard[i * col + j] == player)
                    ++count;
        return count;
    }
    
    
    int Reversi::scorer(const char *tempBoard, const  char player) const        ///////////
    {
        int hold_given = symbol_counter(tempBoard, player);
        int hold_rival;
        if (player == p_symbol)
            hold_rival = symbol_counter(tempBoard, c_symbol);
        else
            hold_rival = symbol_counter(tempBoard, p_symbol);
        return hold_given - hold_rival;
    }
    
    int Reversi::playable_moves(const char *tempBoard, vector< vector<bool> > &moves,const  char player) const  ////////////
    {
        bool go_on;
        int wriggles_count = 0;
        
        for(int i = 0 ; i < row ; ++i)
            for(int j = 0 ; j < col ; ++j)
                moves[i][j] = false;
        
        // search legal playable dots
        for(int i = 0 ; i < row; ++i)
            for(int j = 0 ; j < col ; ++j)
            {
                if(tempBoard[i * col + j] != what_symbol)  // if not dot
                    continue;                   // don't do rest of the code
                // increment the loop
                
                for(int ii = 1 ; ii > -2 ; --ii)
                    for(int jj = 1 ; jj > -2 ; --jj)
                    {
                        
                        if(check_boundry_for_rival(i, j, ii, jj, row, col))
                            continue;
                        
                        if(specify_rival(player) == tempBoard[(i + ii) * col + (j + jj)])
                        {
                            go_on = true;
                            int x_coor = i + ii;
                            int y_coor = j + jj;
                            
                            
                            while(go_on)
                            {
                                x_coor += ii;
                                y_coor += jj;
                                
                                if(check_boundry_for_player(x_coor, y_coor, row, col)
                                   || tempBoard[x_coor * col + y_coor] == what_symbol)
                                    go_on = false;
                                
                                else if(player == tempBoard[x_coor * col + y_coor])
                                {
                                    wriggles_count += 1;
                                    
                                    moves[i][j] = true;
                                    go_on = false;
                                }
                            }
                        }
                    }
            }
        return wriggles_count;
    }
    
    ////////////////////
    
    int Reversi::not_smart_not_bad(const char *tempBoard, vector< vector<bool> > &moves,const  char player) const       ////////////
    {
        int max_score = 0;
        int score = 0;
        char *copy_of_copy_board = new char[ row * col ];
        
        
        for(int i = 0 ; i < row ; ++i)
            for(int j = 0 ; j < col ; ++j)
            {
                if(moves[i][j] == false)
                    continue;
                
                for(int i = 0 ; i < row ; ++i)
                    for(int j = 0 ; j < col ; ++j)
                    {
                        copy_of_copy_board[i * col + j] = tempBoard[i * col + j];
                    }
                
                mover(copy_of_copy_board, i, j, player);
                score = scorer(copy_of_copy_board, player);
                
                if(max_score < score)
                    max_score = score;
            }
        
        delete [] copy_of_copy_board;
        
        
        return max_score;
    }
    
    
    ///////////////////////
    
    
}

