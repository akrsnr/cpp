//
//  reversi.hpp
//  withheader
//
//  Created by Soner on 11.12.2015.
//  Copyright © 2015 Soner. All rights reserved.
//

#ifndef reversi_h
#define reversi_h

#include "cell.h"
#include <iostream>
#include <vector>
#include <iomanip>
using namespace std;

namespace REVERSI
{
    using namespace CELL;
    
    class Reversi
    {
    private:
        
        int row;
        int col;
        
        static char const c_symbol = 'x';      // symbol of comp
        static char const p_symbol = 'o';      // symbol of player
        static char const what_symbol = '.';   // what char get fit board
        
        Cell *gameCells;
        
        Cell wrongInput; // srt -1000, -1000
        
        int moveCount;
        int illegalMove;
        bool p_turn;
        bool playable;
        vector< vector<bool> > moves;
        
        bool checker() const;  // check whether game is end or not
        int playable_moves(const char *tempBoard, vector< vector<bool> > &moves,const  char player) const;
        int not_smart_not_bad(const char *tempBoard, vector< vector<bool> > &moves,const  char player) const;
        int symbol_counter(const char *tempBoard, const  char player) const;
        int scorer(const char *tempBoard, const  char player) const;
        void machine_moves(char *tempBoard, const  char player) const;
        void mover(char *tempBoard, const int i,const int j,const  char player) const;
        void boardSizeCheck() const;  // board boundries control
        
        char specify_rival(const char player) const;
        bool check_boundry_for_rival(const int i,const int j,
                                     const int around_r,const int around_c,const int row,const int col) const;
        bool check_boundry_for_player(const int i,const int j, const int row,const int col) const;
        
        static const int MIN_SIZE = 2; // minimum board size
        static const int rowAlignment = 2; // minimum alignment for row
        static const int colAlignment = 3; // minimum alignment for col
        static int countAlive;  // count live cells
        
    public:
        
        // constructors
        
        Reversi();
        Reversi(int size);
        Reversi(const int x,const int y);
        Reversi(const Reversi& other) ;
        
        Reversi operator= (const Reversi& other);
        
        // destructor
        ~Reversi();
        
        // return live cells
        static int countFunc();
        
        // getters
        int getRow() const;
        int getCol() const;
        
        // setters
        inline void setRow(const int row_) { row = row_; boardSizeCheck(); }
        inline void setCol(const int col_) { col = col_; boardSizeCheck(); }
        void setRowCol(const int _row,const int _col);
        
        // print on the screen
        void show() const;
        
        void play();    // play single step for computer
        void play( Cell var ); // for user
        
        void playGame();    // ask user who one should start and board size
        
        // compare two objects
        bool comparator(const Reversi& obj) const;
        
        void operator++(int dummy);
        Reversi& operator++();
        
        friend ostream& operator<<(ostream& out, const Reversi& other);
        
    };
    
    // test call by reference
    void testRef(REVERSI::Reversi& obj);
    // test call by value
    void testCal(REVERSI::Reversi obj);
    
}

#endif /* reversi_hpp */
