#include <iostream>
#include <cstdlib>
#include "cell.h"
#include "reversi.h"
using namespace std;

using namespace CELL;
using namespace REVERSI;
int main( )
{
    Reversi obj1(4,4);
    Cell test;
    
    obj1.play();
    obj1.show();
    obj1.play(test);    // 3 4
    //obj1.playGame();
    obj1.show();
    
    cout << "obj2" << endl;
    Reversi obj2;
    obj2.show();
    
    cout << "obj3" << endl;
    Reversi obj3;
    obj3 = obj2;
    obj3.show();
    
    
    obj2.play();
    obj2.play(test);    // 1 2
    cout << "obj2" << endl;
    obj2.show();
    cout << "obj1" << endl;
    obj1.show();
    
    cout << "++obj1" << endl;
    
    ++obj1;
    obj1.show();
    
    cout << "obj1++" << endl;
    
    obj1++;
    obj1.show();
    
    // test call by reference
    testRef(obj1);
    // test call by value
    testCal(obj1);
    
    cout << endl << "resize 5, 8" << endl;
    // resize
    obj1.setRowCol(5, 8);
    obj1.show();
    
    return 0;
}
