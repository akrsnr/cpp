//
//  cell.cpp
//  withheader
//
//  Created by Soner on 11.12.2015.
//  Copyright © 2015 Soner. All rights reserved.
//

#include "cell.h"

namespace CELL
{
    void Cell::setX(int x_)
    {
        //this->x = x_;
        x = x_;
    }
    
    void Cell::setY(int y_)
    {
        //this->y = y_;
        y = y_;
    }
    
    void Cell::setChar(char z_)
    {
        z = z_;
    }
    
    char Cell::getChar() const
    {
        return z;
    }
    
    
    int Cell::getX() const
    {
        return x;
    }
    
    int Cell::getY() const
    {
        return y;
    }
}
