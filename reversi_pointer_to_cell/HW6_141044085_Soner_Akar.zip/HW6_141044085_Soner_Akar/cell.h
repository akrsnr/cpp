//
//  cell.hpp
//  withheader
//
//  Created by Soner on 11.12.2015.
//  Copyright © 2015 Soner. All rights reserved.
//

#ifndef cell_h
#define cell_h

#include <iostream>

namespace CELL
{
    
    class Cell
    {
    public:
        explicit Cell(int x_ = 0, int y_ = 0) : x(x_), y(y_) {  }
        
        // setters
        
        void setChar(char z_);
        void setX(int x_);
        void setY(int y_);
        
        // getters
        
        char getChar() const;
        int getX() const;
        int getY() const;
        
        const Cell operator++(int dummy);
        Cell& operator++();
        
        friend std::ostream& operator<<(std::ostream& out, const Cell& other);
        friend std::istream& operator>>(std::istream &in, Cell& other);
        
    private:
        char z;
        int x;
        int y;
    };
    
}


#endif /* cell_h */
