// Soner Akar - 141044085 - HW#02
// return the first element apperaring
// mostly in an array in given types
// (int, char, double, dayofyear, person)
// dayofyear class quoted from the course book

#include <iostream>
#include <cstdlib> //exit
using std::cout;
using std::cin;
using std::endl;

int const SIZE = 10;


struct Person
{
    double height;
    int weight;
};


class DayOfYear
{
public:
    DayOfYear(int monthValue, int dayValue);
    DayOfYear(int monthValue);
    DayOfYear( );
    
    void set(int monthValue, int dayValue);
    void set(int monthValue);
    void set( );
    
    int getMonth( ) const;
    int getday( ) const;
private:
    int month;
    int day;
    void testDate( );
};


// Function prototypes

int return_mode (const void * base, size_t num, size_t size,
                 bool (* equals) (const void *, const void *));

void setStruct(struct Person& obj, double height, int weight);

bool compare_int(void const *e1, void const *e2);
bool compare_double(void const *e1, void const *e2);
bool compare_char(void const *e1, void const *e2);
bool compare_dayofyear(void const *e1, void const *e2);
bool compare_person(void const *e1, void const *e2);



int main()
{
    // Test - 1
    // Integer test - 4
    int arr_int[] = {2 ,4, 6, 8, 5, 5, -1, 5, 9, 9};
    int returnInt;
    returnInt = return_mode(arr_int, SIZE, sizeof(*arr_int), compare_int);
    cout << "index for Integer array => " << returnInt << endl;
    
    //--------------------------------------------------------------------//
    
    // Test - 2
    // Double test - 3
    double arr_double[] = {8.4 ,4.9, 0.6, 5.4, 5.4, 5.4, -1.3, 5.4, 9.2, 9.2};
    int returnDouble;
    returnDouble = return_mode(arr_double, SIZE, sizeof(*arr_double), compare_double);
    cout << "index for Double array => " << returnDouble << endl;
    
    //--------------------------------------------------------------------//

    // Test - 3
    // Char test - 2
    char arr_char[] = "izolasyon";
    int returnChar;
    returnChar = return_mode(arr_char, SIZE, sizeof(*arr_char), compare_char);
    cout << "index for Char array => " << returnChar << endl;
    
    //--------------------------------------------------------------------//
    
    // Test - 4
    // DayOfYear test - 3
    DayOfYear arr_testObj[SIZE];
    
    arr_testObj[0].set(1, 2);
    arr_testObj[1].set(2, 2);
    arr_testObj[2].set(0, 2);
    arr_testObj[3].set(3, 2);
    arr_testObj[4].set(3, 2);
    arr_testObj[5].set(8, 2);
    arr_testObj[6].set(8, 2);
    arr_testObj[7].set(8, 2);
    arr_testObj[8].set(3, 2);
    arr_testObj[9].set(3, 2);

    int returnDayofYear;
    returnDayofYear = return_mode(arr_testObj, SIZE, sizeof(*arr_testObj), compare_dayofyear);
    cout << "index for Class array => " << returnDayofYear << endl;
    
    //--------------------------------------------------------------------//
    
    // Test - 5
    // Person test - 6
    struct Person arr_Person[SIZE];
    
    setStruct(arr_Person[0], 1.97, 98);
    setStruct(arr_Person[1], 1.97, 98);
    setStruct(arr_Person[2], 1.17, 98);
    setStruct(arr_Person[3], 1.17, 98);
    setStruct(arr_Person[4], 1.27, 98);
    setStruct(arr_Person[5], 1.70, 98);
    setStruct(arr_Person[6], 1.77, 98);
    setStruct(arr_Person[7], 1.77, 98);
    setStruct(arr_Person[8], 1.77, 98);
    setStruct(arr_Person[9], 1.70, 98);

    int returnPerson;
    returnPerson = return_mode(arr_Person, SIZE, sizeof(*arr_Person), compare_dayofyear);
    cout << "index for Struct array => " << returnPerson << endl;
    
    //--------------------------------------------------------------------//
    
    // Test - 6
    // DayOfYear test - 4
    DayOfYear arr_last[SIZE];
    
    arr_last[0].set(30, 21);
    arr_last[1].set(24, 25);
    arr_last[2].set(10, 2);
    arr_last[3].set(19, 11);
    arr_last[4].set(11, 12);
    arr_last[5].set(8, 5);
    arr_last[6].set(11, 12);
    arr_last[7].set(28, 21);
    arr_last[8].set(13, 22);
    arr_last[9].set(13, 27);
    
    int return_arr_last;
    return_arr_last = return_mode(arr_last, SIZE, sizeof(*arr_last), compare_dayofyear);
    cout << "index for Class array => " << return_arr_last << endl;
    
    
    return 0;
}

int return_mode (const void * base, size_t num, size_t size,
                 bool (* equals) (const void *, const void *))
{
    int max = 0;
    int count;
    int index = 0;
    char* elem = (char*) base;
    
    // compare ith index with other ones
    for (int i = 0 ; i < num; i++)
    {
        count = 0; // zeroize counter
        for (int j = 0 ; j < num; j++)
        {
            // if the result is zero, increase the count
            if ( ! equals(elem + i * size, elem + j * size) )
            {
                // if the selected ith element equals jth one
                // increase counter
                count++;
            }
        }
        // hold max consistent pair in index
        if (max < count)
        {
            max = count;
            index = i;
        }
    }
    // eventually, return the first index of
    // the most apperared element
    return index;
}

// Integer comparator
bool compare_int(void const *e1, void const *e2)
{
    //int const *p1  = (int const *) e1;
    //int const *p2  = (int const *) e2;
    //if(*p1 - *p2 == 0) return true; else return false;
    return *(int const *) e1 - *(int const *) e2;
}

// Double comparator
bool compare_double(void const *e1, void const *e2)
{
    return *(double const *) e1 - *(double const *) e2;
}

// Char comparator
bool compare_char(void const *e1, void const *e2)
{
    return *(char const *) e1 - *(char const *) e2;
}

// dayofyear comparator
bool compare_dayofyear(void const *e1, void const *e2)
{
    DayOfYear const* p1 = (DayOfYear const *) e1;
    DayOfYear const* p2 = (DayOfYear const *) e2;
    return ( (*p1).getday() - (*p2).getday() ) || ((*p1).getMonth() - (*p2).getMonth());
    // If the member elements of the objects pair with each other, return 0
}

// person comparator
bool compare_person(void const *e1, void const *e2)
{
    struct Person const* p1 = (struct Person const *) e1;
    struct Person const* p2 = (struct Person const *) e2;
    return ( (*p1).height - (*p2).height ) || ((*p1).weight - (*p2).weight);
    // If the member elements of the objects pair with each other, return 0
}

DayOfYear::DayOfYear(int monthValue, int dayValue)
                     : month(monthValue), day(dayValue)
{
    testDate( );
}

DayOfYear::DayOfYear(int monthValue) : month(monthValue), day(1)
{
    testDate( );
}

DayOfYear::DayOfYear( ) : month(1), day(1)
{/*Body intentionally empty.*/}

//uses iostream and cstdlib:
void DayOfYear::testDate( )
{
    if ((month < 1) || (month > 12))
    {
        cout << "Illegal month value!\n";
        exit(1);
    }
    if ((day < 1) || (day > 31))
    {
        cout << "Illegal day value!\n";
        exit(1);
    }
}

void DayOfYear::set(int monthValue, int dayValue)
{
    month = monthValue;
    day = dayValue;
}

int DayOfYear::getday() const
{
    return day;
}

int DayOfYear::getMonth() const
{
    return month;
}

void setStruct(struct Person& obj, double height, int weight)
{
    obj.height = height;
    obj.weight = weight;
}


