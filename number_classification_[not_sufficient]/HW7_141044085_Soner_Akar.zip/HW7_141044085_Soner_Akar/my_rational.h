//
//  my_rational.h
//  withheader
//
//  Created by Soner on 16.12.2015.
//  Copyright © 2015 Soner. All rights reserved.
//

#ifndef my_rational_h
#define my_rational_h

namespace BIZ_SONER
{

    class my_rational : public my_real
    {
    public:
        my_rational( int num, int deNum ) : my_real( num, deNum ) { }
    };
    
}

#endif /* my_rational_h */
