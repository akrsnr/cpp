//
//  my_complex.cpp
//  withheader
//
//  Created by Soner on 16.12.2015.
//  Copyright © 2015 Soner. All rights reserved.
//

#include <iostream>
#include "my_complex.h"

namespace BIZ_SONER
{

    const my_complex my_complex::operator+(const my_complex& other) const
    {
        int reNum = other.getReel2() * getReel1() + getReel2() * other.getReel1();
        int reDe = getReel2() * other.getReel2();
        int imNum = other.getIm2() * getIm1() + getIm2() * other.getIm1();
        int imDe = getIm2() * other.getIm2();
        
        //cout << "( " << reNum << " / " << reDe << " ) + ( " << imNum << " / " << imDe << " )" << endl;
        return my_complex( reNum, reDe, imNum, imDe);
    }

    const my_complex my_complex::operator-(const my_complex& other) const
    {
        int reNum = other.getReel2() * getReel1() - getReel2() * other.getReel1();
        int reDe = getReel2() * other.getReel2();
        int imNum = other.getIm2() * getIm1() - getIm2() * other.getIm1();
        int imDe = getIm2() * other.getIm2();
        
        //cout << "( " << reNum << " / " << reDe << " ) - ( " << imNum << " / " << imDe << " )" << endl;
        return my_complex( reNum, reDe, imNum, imDe);
    }

    bool my_complex::operator<(const my_complex& other) const
    {
        double first_val = static_cast<double>(getReel1()) / getReel2();
        double sec_val = static_cast<double>(getIm1()) / getIm2();
        double first_other_val = static_cast<double>(other.getReel1()) / other.getReel2();
        double second_other_val = static_cast<double>(other.getIm1()) / other.getIm2();
        return (first_val * first_val + sec_val * sec_val) <
        (first_other_val * first_other_val + second_other_val * second_other_val);
    }

    std::ostream& operator<< (std::ostream &out, const my_complex& other)
    {
        out << "( " << other.getReel1() << " / " << other.getReel2() << " ) + ( " << other.getIm1() << " / " << other.getIm2() << " )i" << std::endl;
        return out;
    }

    void my_complex::setReNumDenum(int num, int deNum)
    {
        if (num < 0 && deNum < 0)
        {
            num *= -1;
            deNum *= -1;
        }
        else if (deNum < 0)
        {
            num *= -1;
            deNum *= -1;
        }
        setReel1(num);
        setReel2(deNum);
    }

    void my_complex::setImNumDenum(int num, int deNum)
    {
        if (num < 0 && deNum < 0)
        {
            num *= -1;
            deNum *= -1;
        }
        else if (deNum < 0)
        {
            num *= -1;
            deNum *= -1;
        }
        setIm1(num);
        setIm2(deNum);
    }
        
}
