//
//  my_irrational.h
//  withheader
//
//  Created by Soner on 16.12.2015.
//  Copyright © 2015 Soner. All rights reserved.
//

#ifndef my_irrational_h
#define my_irrational_h

namespace BIZ_SONER
{

    class my_irrational : public my_real
    {
    public:
        my_irrational( int num, int deNum ) : my_real( num, deNum ) { }
    };

}

#endif /* my_irrational_h */
