//
//  my_reel.cpp
//  withheader
//
//  Created by Soner on 16.12.2015.
//  Copyright © 2015 Soner. All rights reserved.
//

#include <iostream>
#include "my_reel.h"

namespace BIZ_SONER
{


    bool my_real::operator<(const my_real& other) const
    {
        // düzenlenecek
        double first_val = static_cast<double>(getReel1()) / getReel2();
        double second_val = static_cast<double>(other.getReel1()) / other.getReel2();
        return first_val < second_val;
    }

}