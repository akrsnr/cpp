//
//  my_reel.h
//  withheader
//
//  Created by Soner on 16.12.2015.
//  Copyright © 2015 Soner. All rights reserved.
//

#ifndef my_reel_h
#define my_reel_h
#include <iostream>
#include "my_complex.h"


namespace BIZ_SONER
{


    class my_real : public my_complex
    {
    public:
        my_real( int val1, int val2 )
        {
            setReel1(val1);
            setReel2(val2);
            setIm1(0);
            setIm2(1);
        }
        my_real( int val )
        {
            setReel1(val);
            setReel2(1);
            setIm1(0);
            setIm2(1);
        }
        bool operator<(const my_real& other) const;
    };
    
}

#endif /* my_reel_h */
