#include <iostream>
#include "my_complex.h"
#include "my_reel.h"
#include "my_imaginary.h"
#include "my_rational.h"
#include "my_irrational.h"
#include "my_integer.h"
#include "my_natural.h"
using std::cout;
using std::endl;
using namespace BIZ_SONER;


int main()
{
    cout << "Test for my_complex" << endl;
    my_complex obj(1,2,3,4), obj2(1,2,3,-4);
    
    cout << obj + obj2 << endl;
    cout << (obj < obj2) << endl;
    
    cout << "Test for my_imaginary" << endl;
    my_imaginary obj3(2,2), obj4(1);
    
    cout << obj3 + obj4 << endl;
    cout << (obj3 < obj4) << endl;
    
    cout << "Test for my_real" << endl;
    my_real obj5(3,4), obj6(7);
    
    cout << obj5 + obj6 << endl;
    cout << (obj5 < obj6) << endl;
    
    cout << "Test for my_rational" << endl;
    my_rational obj7(2,3), obj8(5,4);
    
    cout << obj7 + obj8 << endl;
    cout << (obj7 < obj8) << endl;
    
    cout << "Test for my_irrational" << endl;
    my_irrational obj9(1,3), obj10(0,3);
    
    cout << obj9 + obj10 << endl;
    cout << (obj9 < obj10) << endl;
    
    cout << "Test for my_integer" << endl;
    my_integer obj11(3), obj12(-3);
    
    cout << obj11 + obj12 << endl;
    cout << (obj11 < obj12) << endl;
    
    cout << "Test for my_natural" << endl;
    my_natural obj13(1), obj14(8);
    
    cout << obj13 + obj14 << endl;
    cout << (obj13 < obj14) << endl;
    
    return 0;
}