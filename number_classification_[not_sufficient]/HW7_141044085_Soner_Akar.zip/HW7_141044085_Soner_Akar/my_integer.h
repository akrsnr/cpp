//
//  my_integer.h
//  withheader
//
//  Created by Soner on 16.12.2015.
//  Copyright © 2015 Soner. All rights reserved.
//

#ifndef my_integer_h
#define my_integer_h

namespace BIZ_SONER
{

    class my_integer : public my_rational
    {
    public:
        my_integer( int num ) : my_rational( num, 1 ) { }
    };

}

#endif /* my_integer_h */
