//
//  my_imaginary.h
//  withheader
//
//  Created by Soner on 16.12.2015.
//  Copyright © 2015 Soner. All rights reserved.
//

#ifndef my_imaginary_h
#define my_imaginary_h

namespace BIZ_SONER
{


    class my_imaginary : public my_complex
    {
    public:
        my_imaginary( int val1, int val2 )
        {
            setReel1(0);
            setReel2(1);
            setIm1(val1);
            setIm2(val2);
        }
        my_imaginary( int val )
        {
            setReel1(0);
            setReel2(1);
            setIm1(val);
            setIm2(1);
        }
    };
        
}

#endif /* my_imaginary_h */
