//
//  my_natural.h
//  withheader
//
//  Created by Soner on 16.12.2015.
//  Copyright © 2015 Soner. All rights reserved.
//

#ifndef my_natural_h
#define my_natural_h
#include <cstdlib>

namespace BIZ_SONER
{

    class my_natural : public my_integer
    {
    public:
        void check( int test ) const { if(0 > test) { std::cout << "Natural cannot be negative" << std::endl; exit(-1);} }
        my_natural( int num ) : my_integer( num ) { check(num); }
    };

}

#endif /* my_natural_h */
