//
//  my_complex.h
//  withheader
//
//  Created by Soner on 16.12.2015.
//  Copyright © 2015 Soner. All rights reserved.
//

#ifndef my_complex_h
#define my_complex_h

namespace BIZ_SONER
{

    class my_complex
    {
    public:
        
        // accessors
        int getReel1() const { return Reel1; }
        int getIm1() const { return Im1; }
        int getReel2() const { return Reel2; }
        int getIm2() const { return Im2; }
        
        // mutators
        void setReel1( int val_ ) { this->Reel1 = val_; }
        void setIm1( int val_ ) { this->Im1 = val_; }
        void setReel2( int val_ ) { this->Reel2 = val_; }
        void setIm2( int val_ ) { this->Im2 = val_; }
        void setReNumDenum( int num, int deNum );
        void setImNumDenum( int num, int deNum );
        
        // ctors
        my_complex() : my_complex(1) { }
        my_complex( int cVal ) : my_complex( cVal, cVal, cVal, cVal ) { }
        my_complex( int val1, int val2, int val3, int val4 )
        {
            // ( Reel1 / Im1 ) + ( Reel2 / Im2 )i
            Reel1 = val1;
            Im1 = val3;
            Reel2 = val2;
            Im2 = val4;
        }
        
        const my_complex operator+(const my_complex& other) const;
        
        const my_complex operator-(const my_complex& other) const;
        
        bool operator<(const my_complex& other) const;
        
        friend std::ostream& operator<< (std::ostream &out, const my_complex& other);
        
    private:
        int Reel1;
        int Im1;
        int Reel2;
        int Im2;
        
    };

}

#endif /* my_complex_h */
