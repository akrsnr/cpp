/*
 
 Soner AKAR
 141044085
 
 The game takes two coordinates as integeter values
 e.g. 9 10 first is row the other is column coordinate.
 
 comparator function: compare two reversi objects
 readFile function: it reads grid of a game from file, it asks for file name
 writeFile function: it writes grid of a game to file, it asks for file name
 countAlive vairable: it is the static variable that counts live cells
 play() function: play single step for computer
 play(taking argument): play single step for player
 playGame function: it plays the game normally
 show function: print the grid on the screen
 
 
 char const = const char
 int const = const int
 
*/

#include <iostream>
#include <iomanip>
#include <vector>
#include <fstream>
#include <cstdlib>
#include <string>
using namespace std;

class Cell
{
public:
    explicit Cell(int x_ = 0, int y_ = 0) : x(x_), y(y_) {  }
    
    // setters
    
    void setChar(char z_);
    void setX(int x_);
    void setY(int y_);
    
    // getters
    
    char getChar() const;
    int getX() const;
    int getY() const;
private:
    char z;
    int x;
    int y;
};

class Reversi
{
public:
    
    // return live cells
    static int countFunc();
    
    // constructors
    
    Reversi();
    Reversi(int size);
    Reversi(const int x,const int y);
    
    // free moveable steps
    ~Reversi();
    
    // getters
    int getRow() const;
    int getCol() const;
    
    // setters
    inline void setRow(const int row_) { row = row_; }
    inline void setCol(const int col_) { col = col_; }
    void setRowCol(const int _row,const int _col);
    
    // print on the screen
    void show() const;
    
    void play();    // play single step for computer
    void play( Cell var ); // for user
    
    
    void playGame();    // ask user who one should start and board size
    
    // read - write file
    void readFile();
    void writeFile();
    bool fromFile;
    
    // compare two objects
    bool comparator(const Reversi& obj) const;
    
private:
    int row;
    int col;
    
    char const c_symbol = 'x';      // symbol of comp
    char const p_symbol = 'o';      // symbol of player
    char const what_symbol = '.';   // what char get fit board
    
    bool **moves;
    int moveCount;
    int illegalMove;
    bool p_turn;
    bool playable;
    
    bool checker() const;  // check whether game is end or not
    int playable_moves(const vector < vector<char> > &tempBoard, bool **moves,const  char player) const;
    int not_smart_not_bad(const vector < vector<char> > &tempBoard, bool **moves,const  char player) const;
    int symbol_counter(const vector < vector<char> > &tempBoard,const  char player) const;
    int scorer(const vector < vector<char> > &tempBoard,const  char player) const;
    void machine_moves(vector < vector<char> > &tempBoard,const  char player) const;
    void mover(vector < vector<char> > &tempBoard, const int i,const int j,const  char player) const;
    void boardSizeCheck() const;  // board boundries control
    
    char specify_rival(const char player) const;
    bool check_boundry_for_rival(const int i,const int j,
                                 const int around_r,const int around_c,const int row,const int col) const;
    bool check_boundry_for_player(const int i,const int j, const int row,const int col) const;
    
    static const int MIN_SIZE = 2; // minimum board size
    static const int rowAlignment = 2;
    static const int colAlignment = 3;
    static int countAlive;
    vector< vector<Cell> > gameCells;
};


int Reversi::countAlive = 0;


int main( )
{
    Reversi obj1(2,2), obj2, obj3(9), obj4(2,3), obj5(11, 1001);
    
    //obj1.show();
    
    obj1.playGame();
    obj2.playGame();
    obj3.playGame();
    obj4.playGame();
    obj5.playGame();
    
    //obj1.writeFile();
    
    //obj2.readFile();
    //obj2.playGame();
    
    cout << Reversi::countFunc() << endl;   // prints live cells
    cout << obj2.comparator(obj1) << endl;  // compare obj2 with obj1
    
    return 0;
}

/* ---- BELONG TO THE Reversi CLASS ---- */


// Taking a Reversi object to compare which better

bool Reversi::comparator(const Reversi& obj) const
{
    int firstObj = 0;
    int secondObj = 0;
    
    for (unsigned int i = 0; i < gameCells.size(); ++i)
    {
        for (unsigned int j = 0; j < gameCells[i].size(); ++j)
        {
            if (gameCells[i][j].getChar() == p_symbol)
            {
                ++firstObj;
            }
        }
    }
    
    for (unsigned int i = 0; i < obj.gameCells.size(); ++i)
    {
        for (unsigned int j = 0; j < obj.gameCells[i].size(); ++j)
        {
            if (obj.gameCells[i][j].getChar() == p_symbol)
            {
                ++secondObj;
            }
        }
    }
    
    return firstObj > secondObj;

}

// Read from file a grid

void Reversi::readFile()
{
    
    fromFile = true;
    
    char temp;
    ifstream in;
    string s;
    cout << "Enter file name for READ without spaces and extension => ";
    cin >> s;
    s = s + ".txt";
    in.open(s.c_str());
    if (! in.is_open() )
    {
        cerr << "Error file opening in read mode" << endl;
        exit(-1);
    }
    in >> row >> col;
    
    gameCells.clear();
    gameCells.resize(row);
    for (int i = 0; i < row; ++i)
    {
        gameCells[i].resize(col);
    }

    for (unsigned int i = 0; i < gameCells.size(); ++i)
    {
        for (unsigned int j = 0; j < gameCells[i].size(); ++j)
        {
            in >> temp;
            gameCells[i][j].setChar(temp);
        }
    }
}

// write the grid to file

void Reversi::writeFile()
{
    ofstream out;
    string s;
    cout << "Enter file name for WRITE without spaces and extension => ";
    cin >> s;
    s = s + ".txt";
    out.open(s.c_str());
    if (! out.is_open() )
    {
        cerr << "Error file opening in write mode" << endl;
        exit(-1);
    }
    out << row << " " << col << endl;
    
    for (unsigned int i = 0; i < gameCells.size(); ++i)
    {
        for (unsigned int j = 0; j < gameCells[i].size(); ++j)
        {
            out << gameCells[i][j].getChar();
        }
        out << endl;
    }
}

// check whether the game end or not

bool Reversi::checker() const
{
    return moveCount < row * col && playable;
}

int Reversi::countFunc()
{
    return countAlive;
}

// plays game normally

void Reversi::playGame()
{
    Cell temp;
    int x;
    int y;
    
    
    if (fromFile == false)
    {
        cout << "Enter board sizes => ";
        cin >> x >> y;
        setRowCol(x, y);
    }
    
    do
    {
        show();    // print the board on terminal
        
        if((p_turn = !p_turn))  // specify whose turn true for human
        {
            play(temp);
        }
        else
        {
            play();
        }
        
    }while (checker());
    
    show();
    
    vector< vector<char> > symbolHold(row, vector<char>(col));
    for(int i = 0 ; i < row ; ++i)
        for(int j = 0 ; j < col ; ++j)
        {
            symbolHold[i][j] = gameCells[i][j].getChar();
        }
    
    
    cout << "----------The Score Table----------" << endl;
    cout << "Computer => " << symbol_counter(symbolHold, c_symbol) << endl;
    cout << "Player => " << std::setw(colAlignment) << symbol_counter(symbolHold, p_symbol) << endl;


}

// play single step for computer

void Reversi::play()
{
    vector <vector<char> > holdChars;
    
    holdChars.resize(row);
    for (int i = 0; i < row; ++i)
        holdChars[i].resize(col);
    
    for(int i = 0 ; i < row ; ++i)
        for(int j = 0 ; j < col ; ++j)
        {
            holdChars[i][j] = gameCells[i][j].getChar();
        }
    
    if(playable_moves(holdChars, moves, c_symbol))
    {
        moveCount += 1;    // upgrade counter for alive cell
        countAlive += 1;    // upgrade counter for alive cell in static variable
        illegalMove = 0;   // the machine is already played,
        //so get reset the illegal counter
        // convert symbols of the rival to symbols of the machine
        machine_moves(holdChars, c_symbol);
    }
    else
    {   // there is no legal wriggling for the machine
        illegalMove += 1;
        if(1 >= illegalMove)
            cout << "The computer doesn't have"
            << "any playable movement, your turn" << endl;
        else // there is no legal wriggling for the machine and the human
        {
            cout << "The machine and the human"
            << " don't have any movements" << endl;
            playable = false;
        }
    }
    
    for(int i = 0 ; i < row ; ++i)
        for(int j = 0 ; j < col ; ++j)
        {
            gameCells[i][j].setChar(holdChars[i][j]);
        }
}

// plays computer single step

void Reversi::play(Cell var)
{
    int tempX;
    int tempY;
    vector <vector<char> > holdChars;
    
    
    holdChars.resize(row);
    for (int i = 0; i < row; ++i)
        holdChars[i].resize(col);
    
    
    for(int i = 0 ; i < row ; ++i)
        for(int j = 0 ; j < col ; ++j)
        {
            holdChars[i][j] = gameCells[i][j].getChar();
        }
    
    if(playable_moves(holdChars, moves, p_symbol)) // check playable dots by human
    {
        // boundry and mark checking
        cout << "To save press -1"
             << "\nEnter the coordinates to play => ";
        // get inputs
        cin >> tempX;
        
        if (tempX == -1)
        {
            writeFile();
            cout << "You can continue to play enter coors => ";
            cin >> tempX;
        }
        tempX -= 1;  // fix the entered x coordinate
        
        cin >> tempY;
        // fix the entered y coordinate
        tempY -= 1;
        
        var.setX(tempX);
        var.setY(tempY);
        
        while(check_boundry_for_player(var.getX(), var.getY(), row, col)
              || moves[var.getX()][var.getY()] == false)
        {
            cout << "Illegal wriggling. Try again" << endl;
            
            // Re-enter the coordinates until entered rightly
            
            cout << "Enter the coordinates to play => ";
            // get inputs
            cin >> tempX;
            tempX -= 1;  // fix the entered x coordinate
            cin >> tempY;
            // fix the entered y coordinate
            tempY -= 1;
            
            var.setX(tempX);
            var.setY(tempY);
        }
        // convert symbols of the rival to symbols of the human
        mover(holdChars, var.getX(), var.getY(), p_symbol);
        moveCount += 1;    // upgrade both counter for alive cell
        countAlive += 1;    // upgrade counter for alive cell in static variable
    }
    else
    {
        // there is no legal wriggling
        illegalMove += 1;
        if(1 >= illegalMove)
            cout << "You don't have playable move,"
            << "so the machine is playing again" << endl;
        else
        {
            cout << "The machine and the human don't have any movements" << endl;
            playable = false;
        }
    }
    
    for(int i = 0 ; i < row ; ++i)
        for(int j = 0 ; j < col ; ++j)
        {
            gameCells[i][j].setChar(holdChars[i][j]);
        }
}

// print the grid on the screen

void Reversi::show() const
{
    int tempCol;
    int countDigit = 0;
    
    
    cout << endl << setw(colAlignment);
    for(int i = 0 ; i < col ; ++i)
        cout << i + 1;
    cout << endl;
    
    for(int i = 0; i < row; ++i)
    {
        cout << setw(rowAlignment) << i + 1;
        
        
        for(int j = 0; j < col; ++j)
        {
            
            tempCol = j;
            while(tempCol > 0)
            {
                countDigit++;
                tempCol /= 10;
            }
            
            for (int k = 0; k < countDigit - 1; ++k)
            {
                cout << " ";
            }
            
            cout << gameCells[i][j].getChar();
            
            countDigit = 0;
        }
        cout << endl;
    }
    cout << endl;
}

// ctor for no arguments

Reversi::Reversi()
                : row(MIN_SIZE + MIN_SIZE), col(MIN_SIZE + MIN_SIZE)
{
    countAlive += moveCount;    // first initialize for four men
    
    moves = new bool*[row];
    for (int i = 0; i < row; i++)
    {
        moves[i] = new bool[col];
    }
    
    gameCells.resize(row);
    for (int i = 0; i < row; ++i)
        gameCells[i].resize(col);
    
    for(int i = 0; i < row; ++i)
        for(int j = 0; j < col; ++j)
        {
            moves[i][j] = false;
            gameCells[i][j].setChar(what_symbol);
        }
    
    
    int centerh = row / 2;
    int centerw = col / 2;
    
    gameCells[centerh][centerw].setChar(c_symbol);
    gameCells[centerh - 1][centerw - 1].setChar(c_symbol);
    
    gameCells[centerh][centerw - 1].setChar(p_symbol);
    gameCells[centerh - 1][centerw].setChar(p_symbol);
    
    moveCount = MIN_SIZE + MIN_SIZE;
    illegalMove = 0;
    p_turn = false;
    playable = true;
    fromFile = false;
    
}

// ctor for single arguments

Reversi::Reversi(int size)
                : row(size), col(size)
{
    countAlive += moveCount;    // first initialize for four men
    
    moves = new bool*[row];
    for (int i = 0; i < row; i++)
    {
        moves[i] = new bool[col];
    }
    
    gameCells.resize(row);
    for (int i = 0; i < row; ++i)
        gameCells[i].resize(col);
    
    for(int i = 0; i < row; ++i)
        for(int j = 0; j < col; ++j)
        {
            moves[i][j] = false;
            gameCells[i][j].setChar(what_symbol);
        }
    
    int centerh = row / 2;
    int centerw = col / 2;
    
    gameCells[centerh][centerw].setChar(c_symbol);
    gameCells[centerh - 1][centerw - 1].setChar(c_symbol);
    
    gameCells[centerh][centerw - 1].setChar(p_symbol);
    gameCells[centerh - 1][centerw].setChar(p_symbol);
    
    moveCount = MIN_SIZE + MIN_SIZE;
    illegalMove = 0;
    p_turn = false;
    playable = true;
    fromFile = false;
    
}

// ctor for two arguments

Reversi::Reversi(const int x,const int y)
                : row(x), col(y)
{
    boardSizeCheck();
    
    countAlive += moveCount;    // first initialize for four men
    
    moves = new bool*[row];
    for (int i = 0; i < row; i++)
    {
        moves[i] = new bool[col];
    }
    
    gameCells.resize(row);
    for (int i = 0; i < row; ++i)
        gameCells[i].resize(col);
    
    for(int i = 0; i < row; ++i)
        for(int j = 0; j < col; ++j)
        {
            moves[i][j] = false;
            gameCells[i][j].setChar(what_symbol);
        }
    
    int centerh = row / 2;
    int centerw = col / 2;
    
    gameCells[centerh][centerw].setChar(c_symbol);
    gameCells[centerh - 1][centerw - 1].setChar(c_symbol);
    
    gameCells[centerh][centerw - 1].setChar(p_symbol);
    gameCells[centerh - 1][centerw].setChar(p_symbol);
    
    moveCount = MIN_SIZE + MIN_SIZE;
    illegalMove = 0;
    p_turn = false;
    playable = true;
    fromFile = false;
}

// destrcutor 2d moves array

Reversi::~Reversi()
{
    for(int i = 0; i < row; ++i) {
        delete [] moves[i];
    }
    delete [] moves;
}

// getter for row

int Reversi::getRow() const
{
    return row;
}

// getter for column

int Reversi::getCol() const
{
    return col;
}

// setter for row and column

void Reversi::setRowCol(const int _row,const int _col)
{
    
    countAlive -= moveCount;
    
    for(int i = 0; i < row; ++i) {
        delete [] moves[i];
    }
    delete [] moves;
    
    setRow(_row);
    setCol(_col);
    
    boardSizeCheck();
    
    moves = new bool*[row];
    for (int i = 0; i < row; i++)
    {
        moves[i] = new bool[col];
    }
    
    gameCells.resize(row);
    for (int i = 0; i < row; ++i)
        gameCells[i].resize(col);
    
    for(int i = 0; i < row; ++i)
        for(int j = 0; j < col; ++j)
        {
            moves[i][j] = false;
            gameCells[i][j].setChar(what_symbol);
        }
    
    int centerh = row / 2;
    int centerw = col / 2;
    
    gameCells[centerh][centerw].setChar(c_symbol);
    gameCells[centerh - 1][centerw - 1].setChar(c_symbol);
    
    gameCells[centerh][centerw - 1].setChar(p_symbol);
    gameCells[centerh - 1][centerw].setChar(p_symbol);

}

// check board size is ok

void Reversi::boardSizeCheck() const
{
    if (row < MIN_SIZE || col < MIN_SIZE)
    {
        cerr << "Minimum input sizes should be 2 x 2" << endl;
        exit(0);
    }
}



/*----------------------------------------*/

void Reversi::machine_moves(vector < vector<char> > &tempBoard,const  char player) const    ////////////
{
    vector <vector<char> > holdChars;
    int eff_i = 0;
    int eff_j = 0;
    int score = 0;
    int min_score_for_o = row * col + 1;
    vector< vector<char> > copy_board;
    
    copy_board.resize(row);
    for (int i = 0; i < row; ++i)
        copy_board[i].resize(col);
    
    holdChars.resize(row);
    for (int i = 0; i < row; ++i)
        holdChars[i].resize(col);

    bool **copy_wriggles = new bool*[row];
    for(int i = 0; i < row; ++i)
    {
        copy_wriggles[i] = new bool[col];
    }
    
    for(int i = 0 ; i < row ; ++i)
        for(int j = 0 ; j < col ; ++j)
        {
            if(moves[i][j] == false)     // marked true go on otherwise
                continue;                   // increment the loop

            for(int i = 0 ; i < row ; ++i)
                for(int j = 0 ; j < col ; ++j)
                {
                    copy_board[i][j] = tempBoard[i][j];
                }
            
            // play on copy_board
            mover(copy_board, i, j, player);
            
            // search playable wriggles by the rival after this play of the player
            playable_moves(copy_board, copy_wriggles, specify_rival(player));
            
            
            // search the most efficient proper coordinates
            score = not_smart_not_bad(copy_board, copy_wriggles, specify_rival(player));
            if(score < min_score_for_o)
            {
                eff_i = i;
                eff_j = j;
                min_score_for_o = score;
            }
        }
    mover(tempBoard, eff_i, eff_j, player);
    
    cout << "----" << eff_i + 1 << " " << eff_j + 1 << "----"
    << " was played by the machine" << endl;
    
    for(int i = 0; i < row; ++i) {
        delete [] copy_wriggles[i];
    }
    delete [] copy_wriggles;

    
}


void Reversi::mover(vector < vector<char> > &tempBoard, const int i,const int j,const  char player) const  /////////////
{
    bool go_on;
    tempBoard[i][j] = player;
    
    for(int ii = 1 ; ii > -2 ; --ii)
        for(int jj = 1 ; jj > -2 ; --jj)
        {
            if(check_boundry_for_rival(i, j, ii, jj, row, col))
                continue;
            
            if(specify_rival(player) == tempBoard[i + ii][j + jj])
            {
                go_on = true;
                int x_coor = i + ii;
                int y_coor = j + jj;
                
                while(go_on)
                {
                    x_coor += ii;
                    y_coor += jj;
                    
                    
                    if(check_boundry_for_player(x_coor, y_coor, row, col)
                       || tempBoard[x_coor][y_coor] == what_symbol)
                        go_on = false;
                    
                    else if(player == tempBoard[x_coor][y_coor])
                    {
                        x_coor -= ii;
                        y_coor -= jj;
                        
                        while(specify_rival(player) == tempBoard[x_coor][y_coor])
                        {
                            tempBoard[x_coor][y_coor] = player;
                            x_coor -= ii;
                            y_coor -= jj;
                            
                            
                        }
                        go_on = false;
                    }
                }
            }
        }
}

int Reversi::symbol_counter(const vector < vector<char> > &tempBoard,const  char player) const    //////////////
{
    int count = 0;
    for(int i = 0 ; i < row ; ++i)
        for(int j = 0 ; j < col ; ++j)
            if(tempBoard[i][j] == player)
                ++count;
    return count;
}


int Reversi::scorer(const vector < vector<char> > &tempBoard,const  char player) const        ///////////
{
    int hold_given = symbol_counter(tempBoard, player);
    int hold_rival;
    if (player == p_symbol)
        hold_rival = symbol_counter(tempBoard, c_symbol);
    else
        hold_rival = symbol_counter(tempBoard, p_symbol);
    return hold_given - hold_rival;
}

int Reversi::playable_moves(const vector < vector<char> > &tempBoard, bool **moves,const  char player) const  ////////////
{
    bool go_on;
    int wriggles_count = 0;
    
    for(int i = 0 ; i < row ; ++i)
        for(int j = 0 ; j < col ; ++j)
            moves[i][j] = false;
    
    // search legal playable dots
    for(int i = 0 ; i < row; ++i)
        for(int j = 0 ; j < col ; ++j)
        {
            if(tempBoard[i][j] != what_symbol)  // if not dot
                continue;                   // don't do rest of the code
            // increment the loop
            
            for(int ii = 1 ; ii > -2 ; --ii)
                for(int jj = 1 ; jj > -2 ; --jj)
                {
                    
                    if(check_boundry_for_rival(i, j, ii, jj, row, col))
                        continue;
                    
                    if(specify_rival(player) == tempBoard[i + ii][j + jj])
                    {
                        go_on = true;
                        int x_coor = i + ii;
                        int y_coor = j + jj;
                        
                        
                        while(go_on)
                        {
                            x_coor += ii;
                            y_coor += jj;
                            
                            if(check_boundry_for_player(x_coor, y_coor, row, col)
                               || tempBoard[x_coor][y_coor] == what_symbol)
                                go_on = false;
                            
                            else if(player == tempBoard[x_coor][y_coor])
                            {
                                wriggles_count += 1;
                                
                                moves[i][j] = true;
                                go_on = false;
                            }
                        }
                    }
                }
        }
    return wriggles_count;
}

////////////////////

int Reversi::not_smart_not_bad(const vector < vector<char> > &tempBoard, bool **moves,const  char player) const       ////////////
{
    int max_score = 0;
    int score = 0;
    vector< vector<char> > copy_of_copy_board;

    copy_of_copy_board.resize(row);
    for (int i = 0; i < row; ++i)
        copy_of_copy_board[i].resize(col);
    
    for(int i = 0 ; i < row ; ++i)
        for(int j = 0 ; j < col ; ++j)
        {
            if(moves[i][j] == false)
                continue;

            for(int i = 0 ; i < row ; ++i)
                for(int j = 0 ; j < col ; ++j)
            {
                copy_of_copy_board[i][j] = tempBoard[i][j];
            }
            
            mover(copy_of_copy_board, i, j, player);
            score = scorer(copy_of_copy_board, player);
            
            if(max_score < score)
                max_score = score;
        }
    
    
    return max_score;
}


///////////////////////





/*----------------------------------------*/


/* ---- BELONG TO THE CELL CLASS ---- */

void Cell::setX(int x_)
{
    //this->x = x_;
    x = x_;
}

void Cell::setY(int y_)
{
    //this->y = y_;
    y = y_;
}

void Cell::setChar(char z_)
{
    z = z_;
}

char Cell::getChar() const
{
    return z;
}


int Cell::getX() const
{
    return x;
}

int Cell::getY() const
{
    return y;
}

/* ---- BELONG TO GLOBAL FUNCTIONS ---- */

bool Reversi::check_boundry_for_rival(const int i,const int j,
                             const int around_r,const int around_c,const int row,const int col) const
{
    return
    (i == 0 && around_r == -1) || i + around_r >= row || // outta up range
    (j == 0 && around_c == -1) || j + around_c >= col || // outta down range
    (around_r == 0 && around_c == 0);// if the coordinate itself
    
}

bool Reversi::check_boundry_for_player(const int i,const int j, const int row,const int col) const
{
    return row - 1 < i || i < 0 || col - 1 < j || j < 0;
}

char Reversi::specify_rival(const char player) const
{
    if ( p_symbol == player )
        return c_symbol;
    return p_symbol;
}






